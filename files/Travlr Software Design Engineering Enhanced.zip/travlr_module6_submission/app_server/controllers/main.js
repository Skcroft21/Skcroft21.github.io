const tripsData = require('../data/trips.json');

const navigation = [
  { label: 'Home', href: '/', key: 'home' },
  { label: 'Travel', href: '/travel', key: 'travel' },
  { label: 'Rooms', href: '/rooms', key: 'rooms' },
  { label: 'Meals', href: '/meals', key: 'meals' },
  { label: 'News', href: '/news', key: 'news' },
  { label: 'About', href: '/about', key: 'about' },
  { label: 'Contact', href: '/contact', key: 'contact' }
];

const baseViewModel = (pageKey, title) => ({
  title,
  navigation: navigation.map(item => ({ ...item, active: item.key === pageKey }))
});

const apiBaseUrl = (req) => `${req.protocol}://${req.get('host')}/api`;

const fetchJson = async (url) => {
  const response = await fetch(url);
  if (!response.ok) {
    throw new Error(`API request failed with status ${response.status}`);
  }
  return response.json();
};

module.exports.home = async (req, res) => {
  let featuredTrips = tripsData.trips.slice(0, 3);
  try {
    const dbTrips = await fetchJson(`${apiBaseUrl(req)}/trips`);
    if (Array.isArray(dbTrips) && dbTrips.length) {
      featuredTrips = dbTrips.slice(0, 3);
    }
  } catch (err) {
    console.log('Using local trip JSON for home page:', err.message);
  }

  res.render('index', {
    ...baseViewModel('home', 'Travlr Getaways'),
    featuredTrips,
    latestBlogs: [
      {
        title: '2023 Best Beaches Contest Winners',
        date: 'April 02, 2023',
        summary: 'Integer magna leo, posuere et dignissim vitae, porttitor at odio. Pellentesque a metus nec magna placerat volutpat.'
      },
      {
        title: 'Top 10 Diving Spots',
        date: 'May 29, 2023',
        summary: 'Maecenas scelerisque odio quis arcu fringilla malesuada. Nulla facilisi. In libero nulla, fermentum ut pretium ac.'
      }
    ]
  });
};

module.exports.travel = async (req, res) => {
  let trips = tripsData.trips;

  try {
    const apiTrips = await fetchJson(`${apiBaseUrl(req)}/trips`);
    if (Array.isArray(apiTrips) && apiTrips.length) {
      trips = apiTrips;
    }
  } catch (err) {
    console.log('Using local trip JSON for travel page:', err.message);
  }

  res.render('travel', {
    ...baseViewModel('travel', tripsData.pageTitle),
    heroTitle: tripsData.heroTitle,
    intro: tripsData.intro,
    trips
  });
};

module.exports.rooms = (req, res) => {
  res.render('rooms', {
    ...baseViewModel('rooms', 'Rooms - Travlr Getaways'),
    rooms: [
      {
        name: 'First Class Room',
        image: '/images/first-class.jpg',
        description: 'Cras dui sapien, feugiat vitae tristique ut, lobortis tempor orci. Donec pulvinar sagittis metus ut tristique.',
        rate: '$249 / day'
      },
      {
        name: 'Deluxe Room',
        image: '/images/deluxe.jpg',
        description: 'Vestibulum sit amet porttitor odio. Nulla facilisi. Fusce at pretium felis. Mauris volutpat ipsum ac justo mollis.',
        rate: '$180 / day'
      },
      {
        name: 'Suite Room',
        image: '/images/suite.jpg',
        description: 'Etiam convallis mi vel risus pretium sodales. Etiam nunc lorem, ullamcorper vitae laoreet eu, dapibus et nisl.',
        rate: '$320 / day'
      }
    ]
  });
};

module.exports.meals = (req, res) => {
  res.render('meals', {
    ...baseViewModel('meals', 'Meals - Travlr Getaways'),
    meals: [
      {
        name: 'Seafoods',
        image: '/images/seafoods.jpg',
        description: 'Integer magna leo, posuere et dignissim vitae, porttitor at odio. Pellentesque a metus nec magna placerat volutpat.'
      },
      {
        name: 'Buffet',
        image: '/images/buffet.jpg',
        description: 'Nunc nisi mi, elementum sit amet aliquet quis, tristique quis nisl. Curabitur odio lacus, blandit ut hendrerit vulputate.'
      },
      {
        name: 'Desserts',
        image: '/images/desserts.jpg',
        description: 'Proin odio sapien, elementum at tempor non, vulputate eget libero. In hac habitasse platea dictumst.'
      }
    ]
  });
};

module.exports.news = (req, res) => {
  res.render('news', {
    ...baseViewModel('news', 'News - Travlr Getaways'),
    latestNews: [
      'Vestibulum ut justo magna',
      'Nunc in dolor et metus',
      'Suspendisse potenti integer'
    ],
    vacationTips: [
      'Pack light for beach travel',
      'Book diving excursions early',
      'Bring reef-safe sunscreen'
    ]
  });
};

module.exports.about = (req, res) => {
  res.render('about', {
    ...baseViewModel('about', 'About - Travlr Getaways')
  });
};

module.exports.contact = (req, res) => {
  res.render('contact', {
    ...baseViewModel('contact', 'Contact - Travlr Getaways')
  });
};
