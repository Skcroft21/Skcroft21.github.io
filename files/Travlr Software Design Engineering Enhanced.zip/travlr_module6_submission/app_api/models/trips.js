const mongoose = require('mongoose');

const tripSchema = new mongoose.Schema({
  code: {
    type: String,
    required: [true, 'A trip code is required'],
    unique: true,
    trim: true,
    uppercase: true,
    minlength: [3, 'Trip code must be at least 3 characters'],
    maxlength: [12, 'Trip code cannot exceed 12 characters'],
    match: [/^[A-Z0-9-]+$/, 'Trip code can only contain letters, numbers, and hyphens']
  },
  name: {
    type: String,
    required: [true, 'A trip name is required'],
    trim: true,
    minlength: [3, 'Trip name must be at least 3 characters']
  },
  length: {
    type: String,
    required: [true, 'Trip length is required'],
    trim: true
  },
  start: {
    type: String,
    required: [true, 'A start location is required'],
    trim: true
  },
  resort: {
    type: String,
    required: [true, 'A resort is required'],
    trim: true
  },
  perPerson: {
    type: String,
    required: [true, 'A per-person price is required'],
    trim: true,
    match: [/^\$?\d+(\.\d{2})?$/, 'Per-person price must be a valid dollar amount']
  },
  image: {
    type: String,
    required: [true, 'An image path is required'],
    trim: true
  },
  description: {
    type: String,
    required: [true, 'A description is required'],
    trim: true,
    minlength: [10, 'Description must be at least 10 characters']
  },
  body1: {
    type: String,
    required: [true, 'Body paragraph 1 is required'],
    trim: true
  },
  body2: {
    type: String,
    required: [true, 'Body paragraph 2 is required'],
    trim: true
  }
}, {
  collection: 'trips',
  timestamps: true
});

tripSchema.index({ code: 1 }, { unique: true });
tripSchema.index({ name: 'text', resort: 'text', start: 'text', description: 'text' });

mongoose.model('Trip', tripSchema);
