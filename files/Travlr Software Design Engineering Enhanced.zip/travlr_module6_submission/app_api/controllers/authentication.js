const crypto = require('crypto');

const sendJsonResponse = (res, status, content) => {
  res.status(status).json(content);
};

const ADMIN_USERNAME = process.env.TRAVLR_ADMIN_USER || 'admin';
const ADMIN_PASSWORD = process.env.TRAVLR_ADMIN_PASS || 'TravlrAdmin123!';
const JWT_SECRET = process.env.JWT_SECRET || 'development-secret-change-before-deploy';

const base64url = (input) => Buffer.from(input).toString('base64url');

const signToken = (payload) => {
  const header = { alg: 'HS256', typ: 'JWT' };
  const encodedHeader = base64url(JSON.stringify(header));
  const encodedPayload = base64url(JSON.stringify(payload));
  const signature = crypto
    .createHmac('sha256', JWT_SECRET)
    .update(`${encodedHeader}.${encodedPayload}`)
    .digest('base64url');

  return `${encodedHeader}.${encodedPayload}.${signature}`;
};

module.exports.login = (req, res) => {
  const { username, password } = req.body || {};

  if (!username || !password) {
    return sendJsonResponse(res, 400, {
      message: 'Username and password are required.'
    });
  }

  if (username !== ADMIN_USERNAME || password !== ADMIN_PASSWORD) {
    return sendJsonResponse(res, 401, {
      message: 'Invalid administrator credentials.'
    });
  }

  const expiresIn = 7200;
  const token = signToken({
    username,
    role: 'admin',
    exp: Math.floor(Date.now() / 1000) + expiresIn
  });

  return sendJsonResponse(res, 200, {
    token,
    user: { username, role: 'admin' },
    expiresIn
  });
};
