const mongoose = require('mongoose');
const Trip = mongoose.model('Trip');

const sendJsonResponse = (res, status, content) => {
  if (status === 204) {
    return res.status(status).send();
  }
  return res.status(status).json(content);
};

const normalizeText = (value) => typeof value === 'string' ? value.trim() : value;

const escapeRegex = (value) => value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

const normalizeTripPayload = (body = {}) => ({
  code: normalizeText(body.code)?.toUpperCase(),
  name: normalizeText(body.name),
  length: normalizeText(body.length),
  start: normalizeText(body.start),
  resort: normalizeText(body.resort),
  perPerson: normalizeText(body.perPerson),
  image: normalizeText(body.image),
  description: normalizeText(body.description),
  body1: normalizeText(body.body1),
  body2: normalizeText(body.body2)
});

const formatValidationError = (err) => {
  if (err && err.name === 'ValidationError') {
    return Object.values(err.errors).map((e) => e.message).join('; ');
  }
  if (err && err.code === 11000) {
    return 'Trip code must be unique';
  }
  return err?.message || 'Unknown error';
};

const buildTripQuery = (queryParams = {}) => {
  const query = {};
  const search = normalizeText(queryParams.search);
  const resort = normalizeText(queryParams.resort);
  const start = normalizeText(queryParams.start);

  if (search) {
    const searchRegex = new RegExp(escapeRegex(search), 'i');
    query.$or = [
      { code: searchRegex },
      { name: searchRegex },
      { resort: searchRegex },
      { start: searchRegex },
      { description: searchRegex }
    ];
  }

  if (resort) {
    query.resort = new RegExp(escapeRegex(resort), 'i');
  }

  if (start) {
    query.start = new RegExp(escapeRegex(start), 'i');
  }

  return query;
};

module.exports.tripsList = async (req, res) => {
  try {
    const query = buildTripQuery(req.query);
    const trips = await Trip.find(query).sort({ name: 1 }).lean();
    return sendJsonResponse(res, 200, trips);
  } catch (err) {
    return sendJsonResponse(res, 500, {
      message: 'Error retrieving trips',
      error: err.message
    });
  }
};

module.exports.tripsReadOne = async (req, res) => {
  const { tripCode } = req.params;

  if (!tripCode) {
    return sendJsonResponse(res, 400, {
      message: 'tripCode parameter is required'
    });
  }

  try {
    const trip = await Trip.findOne({ code: tripCode.toUpperCase() }).lean();

    if (!trip) {
      return sendJsonResponse(res, 404, {
        message: 'Trip not found'
      });
    }

    return sendJsonResponse(res, 200, trip);
  } catch (err) {
    return sendJsonResponse(res, 500, {
      message: 'Error retrieving trip',
      error: err.message
    });
  }
};

module.exports.tripsAddTrip = async (req, res) => {
  try {
    const trip = await Trip.create(normalizeTripPayload(req.body));
    return sendJsonResponse(res, 201, trip);
  } catch (err) {
    return sendJsonResponse(res, 400, {
      message: 'Error creating trip',
      error: formatValidationError(err)
    });
  }
};

module.exports.tripsUpdateOne = async (req, res) => {
  const { tripCode } = req.params;

  if (!tripCode) {
    return sendJsonResponse(res, 400, {
      message: 'tripCode parameter is required'
    });
  }

  try {
    const trip = await Trip.findOne({ code: tripCode.toUpperCase() });
    if (!trip) {
      return sendJsonResponse(res, 404, {
        message: 'Trip not found'
      });
    }

    const updates = normalizeTripPayload({ ...trip.toObject(), ...req.body });
    Object.assign(trip, updates);
    const savedTrip = await trip.save();
    return sendJsonResponse(res, 200, savedTrip);
  } catch (err) {
    return sendJsonResponse(res, 400, {
      message: 'Error updating trip',
      error: formatValidationError(err)
    });
  }
};

module.exports.tripsDeleteOne = async (req, res) => {
  const { tripCode } = req.params;

  if (!tripCode) {
    return sendJsonResponse(res, 400, {
      message: 'tripCode parameter is required'
    });
  }

  try {
    const deletedTrip = await Trip.findOneAndDelete({ code: tripCode.toUpperCase() }).lean();
    if (!deletedTrip) {
      return sendJsonResponse(res, 404, {
        message: 'Trip not found'
      });
    }

    return sendJsonResponse(res, 204, null);
  } catch (err) {
    return sendJsonResponse(res, 500, {
      message: 'Error deleting trip',
      error: err.message
    });
  }
};
