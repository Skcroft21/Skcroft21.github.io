const express = require('express');
const router = express.Router();
const ctrlTrips = require('../controllers/trips');
const ctrlAuth = require('../controllers/authentication');
const { requireAdmin } = require('../middleware/auth');

router.post('/login', ctrlAuth.login);

router.route('/trips')
  .get(ctrlTrips.tripsList)
  .post(requireAdmin, ctrlTrips.tripsAddTrip);

router.route('/trips/:tripCode')
  .get(ctrlTrips.tripsReadOne)
  .put(requireAdmin, ctrlTrips.tripsUpdateOne)
  .delete(requireAdmin, ctrlTrips.tripsDeleteOne);

module.exports = router;
