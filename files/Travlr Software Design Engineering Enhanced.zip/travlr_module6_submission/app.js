const express = require('express');
const path = require('path');
const hbs = require('hbs');
require('./app_api/models/db');

const app = express();

app.set('views', path.join(__dirname, 'app_server', 'views'));
app.set('view engine', 'hbs');
hbs.registerPartials(path.join(__dirname, 'app_server', 'views', 'partials'));

app.use(express.urlencoded({ extended: false }));
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

const indexRouter = require('./app_server/routes/index');
const apiRouter = require('./app_api/routes/index');

app.use('/', indexRouter);
app.use('/api', apiRouter);

// 404 handlers
app.use('/api/*', (req, res) => {
  res.status(404).json({ message: 'API route not found' });
});

app.use((req, res) => {
  res.status(404).render('about', {
    title: 'Page Not Found - Travlr Getaways',
    navigation: [
      { label: 'Home', href: '/', key: 'home', active: false },
      { label: 'Travel', href: '/travel', key: 'travel', active: false },
      { label: 'Rooms', href: '/rooms', key: 'rooms', active: false },
      { label: 'Meals', href: '/meals', key: 'meals', active: false },
      { label: 'News', href: '/news', key: 'news', active: false },
      { label: 'About', href: '/about', key: 'about', active: false },
      { label: 'Contact', href: '/contact', key: 'contact', active: false }
    ]
  });
});

const port = process.env.PORT || 3000;
app.listen(port, () => {
  console.log(`Travlr app running on http://localhost:${port}`);
});
