# CS 499 Software Design and Engineering Enhancement Notes

Artifact: Travlr Full Stack Web Application (CS-465)
Category: Software Design and Engineering

## Enhancements Completed

1. Added a secure admin login flow for the Angular admin application.
   - New login route: `/login`
   - New API endpoint: `POST /api/login`
   - Protected admin routes in Angular using an AuthGuard.
   - Protected create, update, and delete API routes using a bearer token middleware.

2. Improved backend organization and security.
   - Added `app_api/controllers/authentication.js` for login logic.
   - Added `app_api/middleware/auth.js` to validate admin bearer tokens.
   - Added environment-variable support for admin credentials:
     - `TRAVLR_ADMIN_USER`
     - `TRAVLR_ADMIN_PASS`
     - `JWT_SECRET`
   - Demo defaults are `admin` and `TravlrAdmin123!` for local testing only.

3. Improved validation and error handling.
   - Strengthened Mongoose validation for trip code, trip name, price, and description.
   - Trimmed and normalized API payload values.
   - Returned clearer API error messages for validation failures.

4. Added search and filtering for trip management.
   - API list endpoint now supports query parameters:
     - `search`
     - `resort`
     - `start`
   - Angular admin dashboard includes a filter form and no-results message.

5. Improved user interface and maintainability.
   - Added login page, logout button, signed-in user display, and protected navigation.
   - Added basic responsive styling for the admin login and cards.
   - Updated Angular service layer to send authorization headers for protected actions.

## Local Test Notes

- API syntax was checked with `node -c`.
- Angular admin app was successfully built with `npm run build` after restoring executable permission on `node_modules/.bin/ng` in the sandbox environment.
- The Angular build completed successfully with generated bundles.

## Important Reminder

Before deploying publicly, set strong environment variables and do not rely on the local demo credentials.
