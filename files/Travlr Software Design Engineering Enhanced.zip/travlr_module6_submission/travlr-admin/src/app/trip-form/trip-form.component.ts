import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Trip } from '../models/trip';
import { TripDataService } from '../services/trip-data.service';

@Component({
  selector: 'app-trip-form',
  templateUrl: './trip-form.component.html'
})
export class TripFormComponent implements OnInit {
  trip: Trip = {
    code: '',
    name: '',
    length: '',
    start: '',
    resort: '',
    perPerson: '',
    image: '/images/reef1.jpg',
    description: '',
    body1: '',
    body2: ''
  };

  isEditMode = false;
  error = '';
  isSaving = false;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private tripService: TripDataService
  ) {}

  ngOnInit(): void {
    const tripCode = this.route.snapshot.paramMap.get('tripCode');
    if (tripCode) {
      this.isEditMode = true;
      this.tripService.getTrip(tripCode).subscribe({
        next: (trip) => this.trip = trip,
        error: () => this.error = 'Unable to load the selected trip.'
      });
    }
  }

  saveTrip(): void {
    this.error = '';
    this.isSaving = true;

    const request = this.isEditMode
      ? this.tripService.updateTrip(this.trip.code, this.trip)
      : this.tripService.addTrip(this.trip);

    request.subscribe({
      next: () => this.router.navigate(['/trips']),
      error: (err) => {
        this.error = err?.error?.error || err?.error?.message || 'Unable to save trip.';
        this.isSaving = false;
      }
    });
  }
}
