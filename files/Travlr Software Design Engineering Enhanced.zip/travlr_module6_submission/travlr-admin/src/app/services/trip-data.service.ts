import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Trip } from '../models/trip';
import { AuthService } from './auth.service';

export interface TripSearchFilters {
  search?: string;
  resort?: string;
  start?: string;
}

@Injectable({ providedIn: 'root' })
export class TripDataService {
  private readonly apiUrl = '/api/trips';

  constructor(private http: HttpClient, private authService: AuthService) {}

  getTrips(filters: TripSearchFilters = {}): Observable<Trip[]> {
    let params = new HttpParams();
    Object.entries(filters).forEach(([key, value]) => {
      if (value) {
        params = params.set(key, value);
      }
    });

    return this.http.get<Trip[]>(this.apiUrl, { params });
  }

  getTrip(code: string): Observable<Trip> {
    return this.http.get<Trip>(`${this.apiUrl}/${code}`);
  }

  addTrip(trip: Trip): Observable<Trip> {
    return this.http.post<Trip>(this.apiUrl, trip, this.getAuthOptions());
  }

  updateTrip(code: string, trip: Trip): Observable<Trip> {
    return this.http.put<Trip>(`${this.apiUrl}/${code}`, trip, this.getAuthOptions());
  }

  deleteTrip(code: string): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/${code}`, this.getAuthOptions());
  }

  private getAuthOptions(): { headers: HttpHeaders } {
    const token = this.authService.getToken();
    return {
      headers: new HttpHeaders({
        Authorization: `Bearer ${token}`
      })
    };
  }
}
