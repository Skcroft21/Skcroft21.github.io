import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, tap } from 'rxjs';

interface LoginResponse {
  token: string;
  user: {
    username: string;
    role: string;
  };
  expiresIn: number;
}

@Injectable({ providedIn: 'root' })
export class AuthService {
  private readonly loginUrl = '/api/login';
  private readonly tokenKey = 'travlr_admin_token';
  private readonly userKey = 'travlr_admin_user';

  constructor(private http: HttpClient) {}

  login(username: string, password: string): Observable<LoginResponse> {
    return this.http.post<LoginResponse>(this.loginUrl, { username, password }).pipe(
      tap((response) => {
        localStorage.setItem(this.tokenKey, response.token);
        localStorage.setItem(this.userKey, JSON.stringify(response.user));
      })
    );
  }

  logout(): void {
    localStorage.removeItem(this.tokenKey);
    localStorage.removeItem(this.userKey);
  }

  getToken(): string | null {
    return localStorage.getItem(this.tokenKey);
  }

  isLoggedIn(): boolean {
    return !!this.getToken();
  }

  getUsername(): string {
    const userJson = localStorage.getItem(this.userKey);
    if (!userJson) {
      return '';
    }

    try {
      return JSON.parse(userJson).username || '';
    } catch {
      return '';
    }
  }
}
