import { Component, EventEmitter, Input, Output } from '@angular/core';
import { Trip } from '../models/trip';

@Component({
  selector: 'app-trip-card',
  templateUrl: './trip-card.component.html'
})
export class TripCardComponent {
  @Input() trip!: Trip;
  @Output() edit = new EventEmitter<string>();
  @Output() delete = new EventEmitter<string>();
}
