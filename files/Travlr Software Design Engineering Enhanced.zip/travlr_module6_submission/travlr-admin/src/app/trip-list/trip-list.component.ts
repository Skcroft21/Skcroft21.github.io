import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Trip } from '../models/trip';
import { TripDataService, TripSearchFilters } from '../services/trip-data.service';

@Component({
  selector: 'app-trip-list',
  templateUrl: './trip-list.component.html'
})
export class TripListComponent implements OnInit {
  trips: Trip[] = [];
  error = '';
  isLoading = false;
  filters: TripSearchFilters = {
    search: '',
    resort: '',
    start: ''
  };

  constructor(private tripService: TripDataService, private router: Router) {}

  ngOnInit(): void {
    this.loadTrips();
  }

  loadTrips(): void {
    this.error = '';
    this.isLoading = true;
    this.tripService.getTrips(this.filters).subscribe({
      next: (trips) => {
        this.trips = trips;
        this.isLoading = false;
      },
      error: () => {
        this.error = 'Unable to load trips.';
        this.isLoading = false;
      }
    });
  }

  clearFilters(): void {
    this.filters = { search: '', resort: '', start: '' };
    this.loadTrips();
  }

  editTrip(code: string): void {
    this.router.navigate(['/trips/edit', code]);
  }

  deleteTrip(code: string): void {
    if (!confirm(`Delete trip ${code}?`)) {
      return;
    }

    this.tripService.deleteTrip(code).subscribe({
      next: () => this.loadTrips(),
      error: (err) => this.error = err?.error?.message || 'Unable to delete trip.'
    });
  }
}
