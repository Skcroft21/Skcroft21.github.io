import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../services/auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html'
})
export class LoginComponent {
  username = '';
  password = '';
  error = '';
  isLoading = false;

  constructor(private authService: AuthService, private router: Router) {}

  login(): void {
    this.error = '';
    this.isLoading = true;

    this.authService.login(this.username.trim(), this.password).subscribe({
      next: () => this.router.navigate(['/trips']),
      error: (err) => {
        this.error = err?.error?.message || 'Login failed. Please try again.';
        this.isLoading = false;
      }
    });
  }
}
