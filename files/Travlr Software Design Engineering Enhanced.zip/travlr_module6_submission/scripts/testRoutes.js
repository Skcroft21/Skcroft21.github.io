const baseUrl = process.env.BASE_URL || 'http://localhost:3000/api';

const testEndpoint = async (path) => {
  const response = await fetch(`${baseUrl}${path}`);
  const body = await response.text();
  console.log(`GET ${path} -> ${response.status}`);
  console.log(body);
  console.log('------------------------------------------------------------');
};

const run = async () => {
  await testEndpoint('/trips');
  await testEndpoint('/trips/GAL01');
  await testEndpoint('/trips/NOTREAL');
};

run().catch(err => {
  console.error('Route test error:', err.message);
});
