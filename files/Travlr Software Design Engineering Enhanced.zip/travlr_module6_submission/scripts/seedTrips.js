const mongoose = require('mongoose');
require('../app_api/models/db');
const Trip = mongoose.model('Trip');
const tripsSeed = require('../app_server/data/trips.json').trips;

const seedTrips = async () => {
  try {
    await Trip.deleteMany({});
    const inserted = await Trip.insertMany(tripsSeed);
    console.log(`Inserted ${inserted.length} trips into MongoDB.`);
  } catch (err) {
    console.error('Seed error:', err.message);
  } finally {
    mongoose.connection.close();
  }
};

seedTrips();
