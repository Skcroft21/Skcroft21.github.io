ABCU Course Planner - Enhanced CS 499 Artifact

This enhanced version expands the original CS 300 Project Two application for the Algorithms and Data Structures milestone.

Enhancements included:
- Added three data structure approaches: vector, unordered_map hash table, and binary search tree.
- Added lookup benchmarking to compare vector, hash table, and BST performance.
- Added duplicate course detection.
- Added prerequisite validation for missing prerequisite course references.
- Added keyword/partial search by course number or title.
- Added catalog statistics reporting.
- Added export feature to save a sorted course list to ABCU_sorted_courses.txt.

Files:
- ABCU_Course_Planner_Enhanced.cpp
- courses.csv

Compile example:
g++ -std=c++17 ABCU_Course_Planner_Enhanced.cpp -o ABCU_Course_Planner_Enhanced

Run:
./ABCU_Course_Planner_Enhanced

When prompted to load data, enter:
courses.csv


Visual Studio 2022 Instructions:
1. Double-click ABCU_Course_Planner_Enhanced.sln.
2. Make sure the startup project is ABCU_Course_Planner_Enhanced.
3. Build with Ctrl + Shift + B.
4. Run with Ctrl + F5.
5. At the file prompt, enter: courses.csv

If Visual Studio asks to retarget projects, accept the default Windows SDK/toolset option.
