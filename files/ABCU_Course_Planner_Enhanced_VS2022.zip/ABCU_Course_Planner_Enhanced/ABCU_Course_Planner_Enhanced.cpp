// ABCU_Course_Planner_Enhanced.cpp
// CS 499 Milestone Three - Algorithms and Data Structures Enhancement
// Original artifact: CS 300 ABCU Advising Assistance Program
// Author: Steven Croft
// Enhancement focus: data structure comparison, validation, search, statistics, and export

#include <algorithm>
#include <chrono>
#include <cctype>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <memory>
#include <sstream>
#include <string>
#include <unordered_map>
#include <vector>

using namespace std;

struct Course {
    string number;
    string title;
    vector<string> prerequisites;
};

static string trim(const string& value) {
    size_t first = value.find_first_not_of(" \t\r\n");
    if (first == string::npos) return "";
    size_t last = value.find_last_not_of(" \t\r\n");
    return value.substr(first, last - first + 1);
}

static string toUpper(string value) {
    for (char& ch : value) {
        ch = static_cast<char>(toupper(static_cast<unsigned char>(ch)));
    }
    return value;
}

static vector<string> splitCSV(const string& line) {
    vector<string> parts;
    string token;
    stringstream stream(line);
    while (getline(stream, token, ',')) {
        parts.push_back(trim(token));
    }
    return parts;
}

static bool courseNumberLess(const string& left, const string& right) {
    return left < right;
}

class CourseBST {
private:
    struct Node {
        Course course;
        unique_ptr<Node> left;
        unique_ptr<Node> right;
        explicit Node(const Course& c) : course(c) {}
    };

    unique_ptr<Node> root;

    void insert(unique_ptr<Node>& node, const Course& course) {
        if (!node) {
            node = make_unique<Node>(course);
            return;
        }
        if (course.number < node->course.number) {
            insert(node->left, course);
        }
        else if (course.number > node->course.number) {
            insert(node->right, course);
        }
        else {
            node->course = course;
        }
    }

    const Course* search(const unique_ptr<Node>& node, const string& number) const {
        if (!node) return nullptr;
        if (number == node->course.number) return &node->course;
        if (number < node->course.number) return search(node->left, number);
        return search(node->right, number);
    }

    void inOrder(const unique_ptr<Node>& node, vector<Course>& output) const {
        if (!node) return;
        inOrder(node->left, output);
        output.push_back(node->course);
        inOrder(node->right, output);
    }

public:
    void clear() { root.reset(); }
    void insert(const Course& course) { insert(root, course); }
    const Course* search(const string& number) const { return search(root, number); }

    vector<Course> sortedCourses() const {
        vector<Course> output;
        inOrder(root, output);
        return output;
    }
};

class CoursePlanner {
private:
    vector<Course> courseVector;
    unordered_map<string, Course> courseMap;
    CourseBST courseTree;
    vector<string> validationMessages;
    vector<string> duplicateMessages;

    const Course* findInVector(const string& number) const {
        for (const Course& course : courseVector) {
            if (course.number == number) return &course;
        }
        return nullptr;
    }

public:
    bool loadCourses(const string& filename) {
        ifstream file(filename);
        if (!file.is_open()) {
            cout << "Unable to open file: " << filename << endl;
            return false;
        }

        courseVector.clear();
        courseMap.clear();
        courseTree.clear();
        validationMessages.clear();
        duplicateMessages.clear();

        string line;
        int lineNumber = 0;
        while (getline(file, line)) {
            lineNumber++;
            line = trim(line);
            if (line.empty()) continue;

            vector<string> parts = splitCSV(line);
            if (parts.size() < 2 || trim(parts[0]).empty() || trim(parts[1]).empty()) {
                validationMessages.push_back("Line " + to_string(lineNumber) + " skipped because it is missing a course number or title.");
                continue;
            }

            Course course;
            course.number = toUpper(parts[0]);
            course.title = parts[1];

            for (size_t i = 2; i < parts.size(); ++i) {
                string prereq = toUpper(trim(parts[i]));
                if (!prereq.empty()) {
                    course.prerequisites.push_back(prereq);
                }
            }

            if (courseMap.find(course.number) != courseMap.end()) {
                duplicateMessages.push_back("Duplicate course found and replaced: " + course.number);
            }

            courseMap[course.number] = course;
        }

        for (const auto& pair : courseMap) {
            courseVector.push_back(pair.second);
            courseTree.insert(pair.second);
        }

        sort(courseVector.begin(), courseVector.end(), [](const Course& a, const Course& b) {
            return courseNumberLess(a.number, b.number);
        });

        validatePrerequisites();
        return !courseVector.empty();
    }

    void validatePrerequisites() {
        for (const Course& course : courseVector) {
            for (const string& prereq : course.prerequisites) {
                if (courseMap.find(prereq) == courseMap.end()) {
                    validationMessages.push_back(course.number + " references missing prerequisite " + prereq + ".");
                }
            }
        }
    }

    const Course* findCourse(const string& number) const {
        string key = toUpper(trim(number));
        auto found = courseMap.find(key);
        if (found == courseMap.end()) return nullptr;
        return &found->second;
    }

    void printCourseList() const {
        if (courseVector.empty()) {
            cout << "No courses loaded." << endl;
            return;
        }
        cout << "\nCourse List:" << endl;
        for (const Course& course : courseVector) {
            cout << course.number << ", " << course.title << endl;
        }
    }

    void printCourse(const string& number) const {
        const Course* course = findCourse(number);
        if (!course) {
            cout << "Course not found." << endl;
            return;
        }

        cout << "\n" << course->number << ", " << course->title << endl;
        if (course->prerequisites.empty()) {
            cout << "Prerequisites: None" << endl;
        }
        else {
            cout << "Prerequisites: ";
            for (size_t i = 0; i < course->prerequisites.size(); ++i) {
                cout << course->prerequisites[i];
                const Course* prereqCourse = findCourse(course->prerequisites[i]);
                if (prereqCourse) cout << " (" << prereqCourse->title << ")";
                if (i + 1 < course->prerequisites.size()) cout << ", ";
            }
            cout << endl;
        }
    }

    void searchByKeyword(const string& keyword) const {
        string searchValue = toUpper(trim(keyword));
        bool foundAny = false;
        cout << "\nSearch Results:" << endl;
        for (const Course& course : courseVector) {
            string titleUpper = toUpper(course.title);
            if (course.number.find(searchValue) != string::npos || titleUpper.find(searchValue) != string::npos) {
                cout << course.number << ", " << course.title << endl;
                foundAny = true;
            }
        }
        if (!foundAny) {
            cout << "No matching courses found." << endl;
        }
    }

    void printStatistics() const {
        int coursesWithPrereqs = 0;
        int totalPrereqs = 0;
        for (const Course& course : courseVector) {
            if (!course.prerequisites.empty()) coursesWithPrereqs++;
            totalPrereqs += static_cast<int>(course.prerequisites.size());
        }

        cout << "\nCatalog Statistics:" << endl;
        cout << "Total courses loaded: " << courseVector.size() << endl;
        cout << "Courses with prerequisites: " << coursesWithPrereqs << endl;
        cout << "Total prerequisite references: " << totalPrereqs << endl;
        cout << "Duplicate warnings: " << duplicateMessages.size() << endl;
        cout << "Validation warnings: " << validationMessages.size() << endl;

        if (!duplicateMessages.empty()) {
            cout << "\nDuplicate Details:" << endl;
            for (const string& message : duplicateMessages) cout << "- " << message << endl;
        }

        if (!validationMessages.empty()) {
            cout << "\nValidation Details:" << endl;
            for (const string& message : validationMessages) cout << "- " << message << endl;
        }
    }

    void benchmarkLookups() const {
        if (courseVector.empty()) {
            cout << "No courses loaded." << endl;
            return;
        }

        vector<string> keys;
        for (const Course& course : courseVector) keys.push_back(course.number);
        const int iterations = 10000;

        auto startVector = chrono::high_resolution_clock::now();
        int vectorHits = 0;
        for (int i = 0; i < iterations; ++i) {
            for (const string& key : keys) {
                if (findInVector(key)) vectorHits++;
            }
        }
        auto endVector = chrono::high_resolution_clock::now();

        auto startHash = chrono::high_resolution_clock::now();
        int hashHits = 0;
        for (int i = 0; i < iterations; ++i) {
            for (const string& key : keys) {
                if (courseMap.find(key) != courseMap.end()) hashHits++;
            }
        }
        auto endHash = chrono::high_resolution_clock::now();

        auto startTree = chrono::high_resolution_clock::now();
        int treeHits = 0;
        for (int i = 0; i < iterations; ++i) {
            for (const string& key : keys) {
                if (courseTree.search(key)) treeHits++;
            }
        }
        auto endTree = chrono::high_resolution_clock::now();

        auto vectorTime = chrono::duration_cast<chrono::microseconds>(endVector - startVector).count();
        auto hashTime = chrono::duration_cast<chrono::microseconds>(endHash - startHash).count();
        auto treeTime = chrono::duration_cast<chrono::microseconds>(endTree - startTree).count();

        cout << "\nLookup Benchmark (" << iterations << " passes):" << endl;
        cout << left << setw(18) << "Data Structure" << setw(16) << "Successful Hits" << "Time (microseconds)" << endl;
        cout << left << setw(18) << "Vector" << setw(16) << vectorHits << vectorTime << endl;
        cout << left << setw(18) << "Hash Table" << setw(16) << hashHits << hashTime << endl;
        cout << left << setw(18) << "Binary Search Tree" << setw(16) << treeHits << treeTime << endl;
    }

    void exportSortedList(const string& filename) const {
        ofstream output(filename);
        if (!output.is_open()) {
            cout << "Unable to create export file." << endl;
            return;
        }

        output << "ABCU Course Planner - Sorted Course List\n";
        output << "--------------------------------------\n";
        for (const Course& course : courseVector) {
            output << course.number << ", " << course.title << "\n";
        }
        cout << "Sorted course list exported to " << filename << endl;
    }
};

static void printMenu() {
    cout << "\nABCU Advising Assistance Program" << endl;
    cout << "1. Load Data Structure" << endl;
    cout << "2. Print Course List" << endl;
    cout << "3. Print Course" << endl;
    cout << "4. Search Courses by Keyword" << endl;
    cout << "5. Show Catalog Statistics and Validation" << endl;
    cout << "6. Run Data Structure Lookup Benchmark" << endl;
    cout << "7. Export Sorted Course List" << endl;
    cout << "9. Exit" << endl;
    cout << "What would you like to do? ";
}

int main() {
    CoursePlanner planner;
    bool loaded = false;
    int choice = 0;

    cout << "Welcome to the enhanced course planner." << endl;

    while (choice != 9) {
        printMenu();
        if (!(cin >> choice)) {
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cout << "Invalid input. Please enter a menu number." << endl;
            continue;
        }
        cin.ignore(numeric_limits<streamsize>::max(), '\n');

        if (choice == 1) {
            cout << "Enter file name (example: courses.csv): ";
            string filename;
            getline(cin, filename);
            filename = trim(filename);
            loaded = planner.loadCourses(filename);
            cout << (loaded ? "Data loaded successfully." : "Data load failed.") << endl;
        }
        else if (choice == 2) {
            if (!loaded) cout << "Please load data first." << endl;
            else planner.printCourseList();
        }
        else if (choice == 3) {
            if (!loaded) cout << "Please load data first." << endl;
            else {
                cout << "Enter course number: ";
                string number;
                getline(cin, number);
                planner.printCourse(number);
            }
        }
        else if (choice == 4) {
            if (!loaded) cout << "Please load data first." << endl;
            else {
                cout << "Enter course number or keyword: ";
                string keyword;
                getline(cin, keyword);
                planner.searchByKeyword(keyword);
            }
        }
        else if (choice == 5) {
            if (!loaded) cout << "Please load data first." << endl;
            else planner.printStatistics();
        }
        else if (choice == 6) {
            if (!loaded) cout << "Please load data first." << endl;
            else planner.benchmarkLookups();
        }
        else if (choice == 7) {
            if (!loaded) cout << "Please load data first." << endl;
            else planner.exportSortedList("ABCU_sorted_courses.txt");
        }
        else if (choice == 9) {
            cout << "Thank you for using the course planner." << endl;
        }
        else {
            cout << choice << " is not a valid option." << endl;
        }
    }

    return 0;
}
