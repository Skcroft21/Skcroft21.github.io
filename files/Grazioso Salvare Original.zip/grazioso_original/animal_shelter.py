from pymongo import MongoClient
from pymongo.errors import ConnectionFailure, OperationFailure

class AnimalShelter:
    def __init__(self, username, password, host='nv-desktop-services.apporto.com', port=31580, db='AAC', collection='animals'):
        try:
            self.client = MongoClient(f"mongodb://{username}:{password}@{host}:{port}/?authSource=admin")
            self.database = self.client[db]
            self.collection = self.database[collection]
            print("Connected to MongoDB successfully.")
        except ConnectionFailure as e:
            print(f"Connection failed: {e}")
        except OperationFailure as e:
            print(f"Authentication failed: {e}")

    def create(self, data):
        if data:
            result = self.collection.insert_one(data)
            return result.acknowledged
        return False

    def read(self, query):
        try:
            return list(self.collection.find(query))
        except Exception as e:
            print(f"Read error: {e}")
            return []

    def update(self, query, new_values):
        try:
            result = self.collection.update_many(query, {'$set': new_values})
            return result.modified_count
        except Exception as e:
            print(f"Update error: {e}")
            return 0

    def delete(self, query):
        try:
            result = self.collection.delete_many(query)
            return result.deleted_count
        except Exception as e:
            print(f"Delete error: {e}")
            return 0