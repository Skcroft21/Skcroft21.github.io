Original CS-340 Grazioso Salvare Project Two files.

Included files:
- ProjectTwoDashboard.py: original dashboard code exported from the notebook
- animal_shelter.py: original MongoDB CRUD module
- Grazioso_Salvare_Project_Two_README.docx: original project README
