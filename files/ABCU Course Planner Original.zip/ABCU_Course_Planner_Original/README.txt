ABCU Course Planner - Original Artifact

This folder contains the original CS 300 Project Two ABCU Advising Assistance Program source code and sample course input file.

Files:
- ABCU_Course_Planner_Original.cpp
- courses.csv

Run with a C++ compiler, then choose option 1 and enter courses.csv when prompted.
