// ProjectTwo.cpp
// CS 300 � ABCU Advising Assistance Program
// Author: Steven Croft
// Date: 10/18/2025
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <unordered_map>
#include <algorithm>
#include <cctype>
#include <limits>

// ------------------------ Utilities ------------------------

static inline std::string ltrim(const std::string& s) {
    size_t i = 0;
    while (i < s.size() && std::isspace(static_cast<unsigned char>(s[i]))) ++i;
    return s.substr(i);
}
static inline std::string rtrim(const std::string& s) {
    if (s.empty()) return s;
    size_t i = s.size();
    while (i > 0 && std::isspace(static_cast<unsigned char>(s[i - 1]))) --i;
    return s.substr(0, i);
}
static inline std::string trim(const std::string& s) { return rtrim(ltrim(s)); }

static inline std::string toUpper(std::string s) {
    for (char& c : s) c = static_cast<char>(std::toupper(static_cast<unsigned char>(c)));
    return s;
}

// Split by comma (simple CSV; suitable for this assignment�s data)
static std::vector<std::string> splitCSV(const std::string& line) {
    std::vector<std::string> out;
    std::stringstream ss(line);
    std::string token;
    while (std::getline(ss, token, ',')) {
        out.push_back(trim(token));
    }
    return out;
}

// Extract alphabetic prefix (dept) and numeric suffix (course number) for sorting
static void splitCourseNum(const std::string& course, std::string& dept, std::string& numericPart) {
    dept.clear();
    numericPart.clear();
    for (char c : course) {
        if (std::isalpha(static_cast<unsigned char>(c))) dept.push_back(static_cast<char>(std::toupper(static_cast<unsigned char>(c))));
        else if (std::isdigit(static_cast<unsigned char>(c))) numericPart.push_back(c);
        // ignore other characters (shouldn't appear in our data)
    }
}

// Alphanumeric compare: first by department (alpha), then by numeric value, then by full string as tiebreaker
static bool courseLess(const std::string& a, const std::string& b) {
    std::string ad, an, bd, bn;
    splitCourseNum(a, ad, an);
    splitCourseNum(b, bd, bn);
    if (ad != bd) return ad < bd;
    // compare numeric value if both numeric parts exist
    if (!an.empty() && !bn.empty()) {
        // remove leading zeros for fair integer comparison length-wise
        auto az = an; az.erase(0, az.find_first_not_of('0'));
        auto bz = bn; bz.erase(0, bz.find_first_not_of('0'));
        if (az.size() != bz.size()) return az.size() < bz.size();
        if (az != bz) return az < bz;
    }
    else if (!an.empty() || !bn.empty()) {
        // one has number, the other doesn't: numbers come after pure dept codes
        return bn.empty(); // if b has no number, a<b is false; if a has no number, a<b is true
    }
    // fallback to full string compare
    return a < b;
}

// ------------------------ Data Model ------------------------

struct Course {
    std::string number;                     // e.g., "CSCI200"
    std::string title;                      // e.g., "Data Structures"
    std::vector<std::string> prereqNums;    // e.g., {"CSCI101", "MATH201"}
};

class Catalog {
public:
    // Returns true if loaded at least one course
    bool loadFromCSV(const std::string& filename, std::string& errorMsg) {
        errorMsg.clear();
        std::ifstream in(filename);
        if (!in) {
            errorMsg = "Error: Could not open file: " + filename;
            return false;
        }

        // Reset existing data
        courses_.clear();

        std::string line;
        size_t lineNum = 0;
        size_t added = 0;
        while (std::getline(in, line)) {
            ++lineNum;
            line = trim(line);
            if (line.empty()) continue;

            auto parts = splitCSV(line);
            if (parts.size() < 2) {
                // Malformed line, skip but record
                malformed_.push_back("Line " + std::to_string(lineNum) + " is malformed (needs at least courseNumber and courseTitle).");
                continue;
            }

            Course c;
            c.number = toUpper(parts[0]);
            c.title = parts[1];

            // Collect prerequisites, if any
            for (size_t i = 2; i < parts.size(); ++i) {
                if (!parts[i].empty())
                    c.prereqNums.push_back(toUpper(parts[i]));
            }

            // Insert / overwrite (last occurrence wins)
            courses_[c.number] = std::move(c);
            ++added;
        }

        if (added == 0) {
            errorMsg = "Error: No course rows were loaded from file: " + filename;
            return false;
        }
        return true;
    }

    bool isEmpty() const {
        return courses_.empty();
    }

    std::vector<std::string> listCourseNumbersSorted() const {
        std::vector<std::string> keys;
        keys.reserve(courses_.size());
        for (const auto& kv : courses_) keys.push_back(kv.first);
        std::sort(keys.begin(), keys.end(), courseLess);
        return keys;
    }

    // Returns nullptr if not found
    const Course* findCourse(const std::string& number) const {
        auto it = courses_.find(toUpper(number));
        if (it == courses_.end()) return nullptr;
        return &it->second;
    }

    // Resolve prerequisite titles for printing
    std::vector<std::pair<std::string, std::string>> resolvePrereqs(const Course& c) const {
        std::vector<std::pair<std::string, std::string>> out;
        for (const auto& p : c.prereqNums) {
            const Course* pc = findCourse(p);
            out.emplace_back(p, pc ? pc->title : std::string("(title not found)"));
        }
        return out;
    }

    // Optional: expose any malformed notifications
    const std::vector<std::string>& malformedLines() const { return malformed_; }

private:
    std::unordered_map<std::string, Course> courses_;
    std::vector<std::string> malformed_;
};

// ------------------------ UI / Printing ------------------------

static void printBanner() {
    std::cout << "Welcome to the course planner.\n";
}

static void printMenu() {
    std::cout << "1. Load Data Structure.\n";
    std::cout << "2. Print Course List.\n";
    std::cout << "3. Print Course.\n";
    std::cout << "9. Exit\n";
    std::cout << "What would you like to do? ";
}

static void printCourseList(const Catalog& catalog) {
    auto sorted = catalog.listCourseNumbersSorted();
    if (sorted.empty()) {
        std::cout << "No courses loaded.\n";
        return;
    }
    std::cout << "Here is a sample schedule:\n";
    for (const auto& num : sorted) {
        const Course* c = catalog.findCourse(num);
        if (!c) continue;
        std::cout << c->number << ", " << c->title << "\n";
    }
}

static void printCourseInfo(const Catalog& catalog) {
    std::cout << "What course do you want to know about? ";
    std::string query;
    // read full token; accept spaces trimmed
    std::getline(std::cin, query);
    query = trim(query);
    if (query.empty()) {
        std::cout << "Please enter a course number like CSCI200 or MATH201.\n";
        return;
    }
    const Course* c = catalog.findCourse(query);
    if (!c) {
        std::cout << toUpper(query) << " not found.\n";
        return;
    }
    std::cout << c->number << ", " << c->title << "\n";

    auto prereqs = catalog.resolvePrereqs(*c);
    if (prereqs.empty()) {
        std::cout << "Prerequisites: None\n";
    }
    else {
        std::cout << "Prerequisites: ";
        for (size_t i = 0; i < prereqs.size(); ++i) {
            const auto& pr = prereqs[i];
            std::cout << pr.first;
            if (pr.second != "(title not found)") {
                std::cout << " (" << pr.second << ")";
            }
            if (i + 1 < prereqs.size()) std::cout << ", ";
        }
        std::cout << "\n";
    }
}

// ------------------------ Main Loop ------------------------

int main() {
    Catalog catalog;

    printBanner();

    bool running = true;
    bool loaded = false;

    while (running) {
        printMenu();

        int choice = 0;
        if (!(std::cin >> choice)) {
            // handle non-integer input
            std::cin.clear();
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            std::cout << "Invalid input. Please enter a number like 1, 2, 3, or 9.\n";
            continue;
        }

        // consume the rest of the line so getline works after numeric input
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

        switch (choice) {
        case 1: {
            std::cout << "Enter the file name to load (e.g., courses.csv): ";
            std::string filename;
            std::getline(std::cin, filename);
            filename = trim(filename);
            if (filename.empty()) {
                std::cout << "No file name entered. Try again.\n";
                break;
            }
            std::string err;
            if (catalog.loadFromCSV(filename, err)) {
                loaded = true;
                // Show any non-fatal malformed lines encountered
                const auto& notes = catalog.malformedLines();
                if (!notes.empty()) {
                    std::cout << "Note: Some lines were skipped due to format issues:\n";
                    for (const auto& n : notes) std::cout << "  - " << n << "\n";
                }
                std::cout << "Data load complete.\n";
            }
            else {
                std::cout << err << "\n";
                loaded = false;
            }
            break;
        }
        case 2:
            if (!loaded || catalog.isEmpty()) {
                std::cout << "Please load the data first (option 1).\n";
            }
            else {
                printCourseList(catalog);
            }
            break;

        case 3:
            if (!loaded || catalog.isEmpty()) {
                std::cout << "Please load the data first (option 1).\n";
            }
            else {
                printCourseInfo(catalog);
            }
            break;

        case 9:
            std::cout << "Thank you for using the course planner!\n";
            running = false;
            break;

        default:
            std::cout << choice << " is not a valid option.\n";
            break;
        }
    }

    return 0;
}