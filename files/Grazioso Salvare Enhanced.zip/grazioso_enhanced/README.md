# Enhanced Grazioso Salvare Dashboard - CS 499 Milestone Four

This enhanced database artifact builds on the CS-340 Grazioso Salvare dashboard.
It demonstrates database-focused improvements using MongoDB, Python, Dash, Plotly,
Pandas, and Dash Leaflet.

## Enhanced Features

- Added environment-based MongoDB configuration.
- Added MongoDB index creation for common dashboard query fields.
- Added advanced filtering by rescue type, breed search, outcome type, and age range.
- Added summary analytics cards for filtered records, dogs, rescue candidates, and outcome types.
- Added an additional outcome-type visualization.
- Added stronger error handling for MongoDB connection, query, aggregation, update, and delete operations.
- Added query validation and optional read parameters such as limit, projection, and sorting.

## Files

- `animal_shelter.py` - enhanced MongoDB CRUD and database helper module.
- `ProjectTwoDashboard_Enhanced.py` - enhanced Dash/JupyterDash dashboard.
- `requirements.txt` - Python dependencies.

## Running the Dashboard

1. Install dependencies:

```bash
pip install -r requirements.txt
```

2. Set MongoDB credentials if different from defaults:

```bash
set AAC_USERNAME=aacuser1
set AAC_PASSWORD=SNHU1234
set AAC_HOST=nv-desktop-services.apporto.com
set AAC_PORT=31580
```

3. Run the dashboard:

```bash
python ProjectTwoDashboard_Enhanced.py
```

If running in Jupyter, the app can also be opened as a notebook cell because it uses JupyterDash.
