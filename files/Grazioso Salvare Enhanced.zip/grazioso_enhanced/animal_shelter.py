"""
Enhanced AnimalShelter CRUD module for CS 499 Milestone Four.
Enhancements include environment-based configuration, safer validation,
index creation, count/aggregate helpers, and stronger error handling.
"""

import os
from typing import Any, Dict, Iterable, List, Optional

from pymongo import MongoClient, ASCENDING
from pymongo.errors import ConnectionFailure, OperationFailure, PyMongoError


class AnimalShelter:
    """MongoDB CRUD helper for the AAC animal shelter collection."""

    ALLOWED_QUERY_FIELDS = {
        "animal_id", "animal_type", "breed", "name", "outcome_type",
        "sex_upon_outcome", "age_upon_outcome_in_weeks", "location_lat",
        "location_long", "datetime", "monthyear"
    }

    def __init__(
        self,
        username: Optional[str] = None,
        password: Optional[str] = None,
        host: Optional[str] = None,
        port: Optional[int] = None,
        db: str = "AAC",
        collection: str = "animals",
        auth_source: str = "admin",
        create_indexes: bool = True,
    ):
        self.username = username or os.getenv("AAC_USERNAME", "aacuser1")
        self.password = password or os.getenv("AAC_PASSWORD", "SNHU1234")
        self.host = host or os.getenv("AAC_HOST", "nv-desktop-services.apporto.com")
        self.port = int(port or os.getenv("AAC_PORT", "31580"))
        self.db_name = db
        self.collection_name = collection
        self.connected = False
        self.client = None
        self.database = None
        self.collection = None

        try:
            connection = f"mongodb://{self.username}:{self.password}@{self.host}:{self.port}/?authSource={auth_source}"
            self.client = MongoClient(connection, serverSelectionTimeoutMS=5000)
            # Force the connection check so errors appear early.
            self.client.admin.command("ping")
            self.database = self.client[self.db_name]
            self.collection = self.database[self.collection_name]
            self.connected = True
            if create_indexes:
                self.create_indexes()
            print("Connected to MongoDB successfully.")
        except (ConnectionFailure, OperationFailure, PyMongoError) as error:
            self.connected = False
            print(f"MongoDB connection error: {error}")

    def create_indexes(self) -> bool:
        """Create indexes on fields used most often by the dashboard filters."""
        if not self.connected:
            return False
        try:
            self.collection.create_index([("animal_type", ASCENDING)], name="idx_animal_type")
            self.collection.create_index([("breed", ASCENDING)], name="idx_breed")
            self.collection.create_index([("outcome_type", ASCENDING)], name="idx_outcome_type")
            self.collection.create_index([("age_upon_outcome_in_weeks", ASCENDING)], name="idx_age_weeks")
            self.collection.create_index(
                [("animal_type", ASCENDING), ("breed", ASCENDING), ("age_upon_outcome_in_weeks", ASCENDING)],
                name="idx_rescue_filter"
            )
            return True
        except PyMongoError as error:
            print(f"Index creation error: {error}")
            return False

    def _valid_document(self, data: Dict[str, Any]) -> bool:
        return isinstance(data, dict) and len(data) > 0

    def _safe_query(self, query: Optional[Dict[str, Any]]) -> Dict[str, Any]:
        """Return a safe query dictionary and reject non-dictionary values."""
        if query is None:
            return {}
        if not isinstance(query, dict):
            raise ValueError("Query must be a dictionary.")
        return query

    def create(self, data: Dict[str, Any]) -> bool:
        """Insert one animal record into MongoDB."""
        if not self.connected or not self._valid_document(data):
            return False
        try:
            result = self.collection.insert_one(data)
            return result.acknowledged
        except PyMongoError as error:
            print(f"Create error: {error}")
            return False

    def read(
        self,
        query: Optional[Dict[str, Any]] = None,
        projection: Optional[Dict[str, int]] = None,
        limit: int = 0,
        sort_field: Optional[str] = None,
        sort_direction: int = ASCENDING,
    ) -> List[Dict[str, Any]]:
        """Read animal records using optional projection, limit, and sorting."""
        if not self.connected:
            return []
        try:
            safe_query = self._safe_query(query)
            cursor = self.collection.find(safe_query, projection)
            if sort_field:
                cursor = cursor.sort(sort_field, sort_direction)
            if limit and limit > 0:
                cursor = cursor.limit(limit)
            return list(cursor)
        except (ValueError, PyMongoError) as error:
            print(f"Read error: {error}")
            return []

    def update(self, query: Dict[str, Any], new_values: Dict[str, Any]) -> int:
        """Update records matching a query."""
        if not self.connected or not self._valid_document(new_values):
            return 0
        try:
            result = self.collection.update_many(self._safe_query(query), {"$set": new_values})
            return result.modified_count
        except (ValueError, PyMongoError) as error:
            print(f"Update error: {error}")
            return 0

    def delete(self, query: Dict[str, Any]) -> int:
        """Delete records matching a query."""
        if not self.connected:
            return 0
        try:
            result = self.collection.delete_many(self._safe_query(query))
            return result.deleted_count
        except (ValueError, PyMongoError) as error:
            print(f"Delete error: {error}")
            return 0

    def count(self, query: Optional[Dict[str, Any]] = None) -> int:
        """Return the number of records matching a query."""
        if not self.connected:
            return 0
        try:
            return self.collection.count_documents(self._safe_query(query))
        except (ValueError, PyMongoError) as error:
            print(f"Count error: {error}")
            return 0

    def aggregate(self, pipeline: Iterable[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Run a MongoDB aggregation pipeline."""
        if not self.connected:
            return []
        try:
            return list(self.collection.aggregate(list(pipeline)))
        except PyMongoError as error:
            print(f"Aggregation error: {error}")
            return []
