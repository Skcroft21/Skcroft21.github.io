#!/usr/bin/env python
# coding: utf-8
"""
Enhanced Grazioso Salvare Dashboard for CS 499 Milestone Four.
Database enhancements include advanced MongoDB filtering, indexed query fields,
summary analytics, stronger validation, and safer connection handling.
"""

import pandas as pd
import plotly.express as px
import dash_leaflet as dl
from jupyter_dash import JupyterDash
from dash import dcc, html, dash_table
from dash.dependencies import Input, Output

from animal_shelter import AnimalShelter


# Database connection uses environment variables if they exist.
shelter = AnimalShelter()

RESCUE_QUERIES = {
    "water": {
        "$and": [
            {"animal_type": "Dog"},
            {"age_upon_outcome_in_weeks": {"$lte": 104}},
            {"breed": {"$in": ["Labrador Retriever Mix", "Chesapeake Bay Retriever", "Newfoundland"]}},
        ]
    },
    "mountain": {
        "$and": [
            {"animal_type": "Dog"},
            {"age_upon_outcome_in_weeks": {"$lte": 156}},
            {"breed": {"$in": ["German Shepherd", "Alaskan Malamute", "Old English Sheepdog", "Siberian Husky", "Rottweiler"]}},
        ]
    },
    "disaster": {
        "$and": [
            {"animal_type": "Dog"},
            {"age_upon_outcome_in_weeks": {"$lte": 300}},
            {"breed": {"$in": ["Doberman Pinscher", "German Shepherd", "Golden Retriever", "Bloodhound", "Rottweiler"]}},
        ]
    },
}


def combine_queries(*queries):
    """Combine multiple MongoDB query fragments using $and."""
    clean = [query for query in queries if query]
    if not clean:
        return {}
    if len(clean) == 1:
        return clean[0]
    return {"$and": clean}


def build_query(rescue_type="reset", breed_search="", outcome_type="", min_age=None, max_age=None):
    """Build a MongoDB query from the dashboard controls."""
    query_parts = []

    if rescue_type in RESCUE_QUERIES:
        query_parts.append(RESCUE_QUERIES[rescue_type])

    if breed_search and breed_search.strip():
        query_parts.append({"breed": {"$regex": breed_search.strip(), "$options": "i"}})

    if outcome_type and outcome_type != "all":
        query_parts.append({"outcome_type": outcome_type})

    age_filter = {}
    if min_age is not None:
        try:
            age_filter["$gte"] = float(min_age)
        except (TypeError, ValueError):
            pass
    if max_age is not None:
        try:
            age_filter["$lte"] = float(max_age)
        except (TypeError, ValueError):
            pass
    if age_filter:
        query_parts.append({"age_upon_outcome_in_weeks": age_filter})

    return combine_queries(*query_parts)


def load_data(query=None):
    """Load MongoDB results into a DataFrame and clean display-only fields."""
    data = shelter.read(query or {}, limit=1000, sort_field="animal_type")
    df = pd.DataFrame(data)
    if df.empty:
        return df
    if "_id" in df.columns:
        df.drop(columns=["_id"], inplace=True)
    return df


def build_stat_cards(df):
    total = len(df)
    dog_count = int((df.get("animal_type") == "Dog").sum()) if "animal_type" in df else 0
    rescue_candidates = dog_count
    outcomes = df["outcome_type"].nunique() if "outcome_type" in df else 0

    cards = [
        ("Filtered Records", total),
        ("Dogs", dog_count),
        ("Rescue Candidates", rescue_candidates),
        ("Outcome Types", outcomes),
    ]
    return html.Div([
        html.Div([html.H4(label), html.H2(value)], className="stat-card")
        for label, value in cards
    ], className="stat-container")


def build_map_points(df):
    points = []
    if "location_lat" not in df or "location_long" not in df:
        return points
    for _, row in df.iterrows():
        lat = row.get("location_lat")
        lon = row.get("location_long")
        if pd.notnull(lat) and pd.notnull(lon):
            label = f"{row.get('name', 'Unknown')} - {row.get('breed', 'Unknown breed')}"
            points.append(dl.Marker(position=[lat, lon], children=dl.Tooltip(label)))
    return points


initial_df = load_data()
columns = [{"name": i, "id": i} for i in initial_df.columns] if not initial_df.empty else []
outcome_options = [{"label": "All", "value": "all"}]
if "outcome_type" in initial_df.columns:
    outcome_options += [
        {"label": outcome, "value": outcome}
        for outcome in sorted(initial_df["outcome_type"].dropna().unique())
    ]

app = JupyterDash(__name__)
app.layout = html.Div([
    html.Style("""
        .stat-container {display: flex; gap: 12px; margin: 15px 0; flex-wrap: wrap;}
        .stat-card {background: #f2f4f7; border: 1px solid #d0d7de; border-radius: 8px; padding: 12px; min-width: 150px; text-align: center;}
        .filter-panel {width: 22%; float: left; padding-right: 20px;}
        .table-panel {width: 74%; float: right;}
    """),
    html.Div([
        html.H2("Grazioso Salvare Dashboard - Steven Croft"),
        html.P("Enhanced database dashboard with MongoDB filtering, indexes, validation, and analytics.")
    ], style={"textAlign": "center"}),

    html.Div([
        html.Label("Select Rescue Type:"),
        dcc.RadioItems(
            id="rescue-type",
            options=[
                {"label": "All", "value": "reset"},
                {"label": "Water Rescue", "value": "water"},
                {"label": "Mountain/Wilderness Rescue", "value": "mountain"},
                {"label": "Disaster/Individual Tracking", "value": "disaster"},
            ],
            value="reset",
            labelStyle={"display": "block"},
        ),
        html.Br(),
        html.Label("Breed Search:"),
        dcc.Input(id="breed-search", type="text", placeholder="Example: Shepherd", debounce=True),
        html.Br(), html.Br(),
        html.Label("Outcome Type:"),
        dcc.Dropdown(id="outcome-type", options=outcome_options, value="all", clearable=False),
        html.Br(),
        html.Label("Age Range in Weeks:"),
        dcc.Input(id="min-age", type="number", placeholder="Min", debounce=True, style={"width": "45%"}),
        dcc.Input(id="max-age", type="number", placeholder="Max", debounce=True, style={"width": "45%", "marginLeft": "5%"}),
    ], className="filter-panel"),

    html.Div([
        html.Div(id="stats-cards"),
        dash_table.DataTable(
            id="datatable",
            columns=columns,
            data=initial_df.to_dict("records"),
            page_size=10,
            style_table={"overflowX": "auto"},
            filter_action="native",
            sort_action="native",
        ),
    ], className="table-panel"),

    html.Div(style={"clear": "both"}),
    dcc.Graph(id="breed-chart"),
    dcc.Graph(id="outcome-chart"),
    dl.Map(
        center=[30.27, -97.74],
        zoom=10,
        children=[dl.TileLayer(), dl.LayerGroup(id="map-points")],
        style={"width": "100%", "height": "500px"},
    ),
])


@app.callback(
    [
        Output("datatable", "data"),
        Output("datatable", "columns"),
        Output("stats-cards", "children"),
        Output("breed-chart", "figure"),
        Output("outcome-chart", "figure"),
        Output("map-points", "children"),
    ],
    [
        Input("rescue-type", "value"),
        Input("breed-search", "value"),
        Input("outcome-type", "value"),
        Input("min-age", "value"),
        Input("max-age", "value"),
    ],
)
def update_dashboard(rescue_type, breed_search, outcome_type, min_age, max_age):
    query = build_query(rescue_type, breed_search, outcome_type, min_age, max_age)
    df = load_data(query)

    if df.empty:
        empty_fig = px.histogram(title="No data found")
        return [], [], build_stat_cards(df), empty_fig, empty_fig, []

    breed_fig = px.histogram(df, x="breed", title="Breed Distribution") if "breed" in df else px.histogram(title="Breed data unavailable")
    outcome_fig = px.histogram(df, x="outcome_type", title="Outcome Type Distribution") if "outcome_type" in df else px.histogram(title="Outcome data unavailable")
    return (
        df.to_dict("records"),
        [{"name": i, "id": i} for i in df.columns],
        build_stat_cards(df),
        breed_fig,
        outcome_fig,
        build_map_points(df),
    )


if __name__ == "__main__":
    app.run_server(mode="inline")
